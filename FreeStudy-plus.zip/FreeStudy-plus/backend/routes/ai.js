const express = require('express');
const router = express.Router();
const { Configuration, OpenAIApi } = require('openai');
const authMiddleware = require('../utils/authMiddleware');

const OPENAI_KEY = process.env.OPENAI_KEY;
let openai;
if(OPENAI_KEY){
  const conf = new Configuration({ apiKey: OPENAI_KEY });
  openai = new OpenAIApi(conf);
}

// simple chat endpoint (requires auth)
router.post('/chat', authMiddleware, async (req,res)=>{
  const {message} = req.body;
  if(!message) return res.status(400).json({error:'Missing message'});
  if(!openai) return res.json({reply:'OpenAI key not configured on server. Please set OPENAI_KEY in .env'});

  try{
    const resp = await openai.createChatCompletion({
      model: "gpt-4o-mini", // replace if needed
      messages: [{role:'user', content: message}],
      max_tokens: 500
    });
    const reply = resp.data.choices?.[0]?.message?.content || 'No reply';
    res.json({reply});
  }catch(err){
    console.error(err);
    res.status(500).json({error: err.message || 'AI error'});
  }
});

module.exports = router;
