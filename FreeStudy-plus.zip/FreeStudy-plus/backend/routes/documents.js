const express = require('express');
const router = express.Router();
const multer = require('multer');
const path = require('path');
const Document = require('../models/Document');
const authMiddleware = require('../utils/authMiddleware');

const upload = multer({ dest: path.join(__dirname, '../uploads/'), limits:{fileSize: 50*1024*1024} });

// public: list documents
router.get('/', async (req,res)=>{
  const docs = await Document.find({visible:true}).limit(50).sort({createdAt:-1}).lean();
  res.json(docs.map(d=>({title:d.title,description:d.description,filePath:'/uploads/'+(d.filePath||''),subject:d.subject,grade:d.grade})));
});

// upload document (authenticated)
router.post('/upload', authMiddleware, upload.single('file'), async (req,res)=>{
  try{
    const {title,description,subject,grade} = req.body;
    const doc = new Document({
      title, description, subject, grade,
      uploader: req.userId,
      filePath: req.file ? req.file.filename : ''
    });
    await doc.save();
    res.json({ok:true, doc});
  }catch(err){ res.status(500).json({error:err.message}); }
});

// admin delete
router.delete('/:id', authMiddleware, async (req,res)=>{
  if(req.userRole !== 'admin') return res.status(403).json({error:'Forbidden'});
  await Document.deleteOne({_id:req.params.id});
  res.json({ok:true});
});

module.exports = router;
