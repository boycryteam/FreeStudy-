const mongoose = require('mongoose');
const docSchema = new mongoose.Schema({
  title: String,
  description: String,
  filePath: String,
  uploader: {type: mongoose.Schema.Types.ObjectId, ref:'User'},
  subject: String,
  grade: String,
  createdAt: {type:Date, default:Date.now},
  visible: {type:Boolean, default:true}
});
module.exports = mongoose.model('Document', docSchema);
