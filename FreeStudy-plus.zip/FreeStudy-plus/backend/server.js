// Minimal Express server for FreeStudy+ (skeleton)
require('dotenv').config();
const express = require('express');
const path = require('path');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const cors = require('cors');
const authRoutes = require('./routes/auth');
const docRoutes = require('./routes/documents');
const aiRoutes = require('./routes/ai');

const app = express();
app.use(cors());
app.use(bodyParser.json());
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// Serve frontend static files (optional)
app.use('/', express.static(path.join(__dirname, '../frontend')));

app.use('/api/auth', authRoutes);
app.use('/api/documents', docRoutes);
app.use('/api/ai', aiRoutes);

const PORT = process.env.PORT || 4000;
const MONGO = process.env.MONGO_URI || 'mongodb://localhost:27017/freestudy_demo';

mongoose.connect(MONGO, {useNewUrlParser:true, useUnifiedTopology:true})
.then(()=>{
  console.log('Mongo connected');
  app.listen(PORT, ()=> console.log('Server listening on', PORT));
}).catch(err=>{
  console.error('Mongo connect error:', err.message);
  app.listen(PORT, ()=> console.log('Server listening without DB on', PORT));
});
