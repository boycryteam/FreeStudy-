// Simple frontend demo that calls backend APIs - endpoints exist in backend skeleton.
const API_BASE = "/api";

document.addEventListener('DOMContentLoaded', ()=>{
  document.getElementById('searchBtn').addEventListener('click', doSearch);
  document.getElementById('chatSend').addEventListener('click', sendChat);
  loadFeatured();
  loadDocs();
});

function loadFeatured(){
  // demo static featured cards
  const featured = [
    {title:'Toán 12 - Ôn luyện THPT', meta:'PDF | 120 trang'},
    {title:'Ngữ văn 11 - Tuyển tập', meta:'PDF | 95 trang'},
    {title:'Tiếng Anh - Grammar & Vocabulary', meta:'PDF | 150 trang'}
  ];
  const container = document.getElementById('featuredList');
  container.innerHTML = '';
  featured.forEach(f => {
    const el = document.createElement('div');
    el.className = 'card';
    el.innerHTML = `<h3>${f.title}</h3><p>${f.meta}</p>`;
    container.appendChild(el);
  });
}

async function loadDocs(){
  // try to fetch from backend
  try{
    const res = await fetch(API_BASE + '/documents');
    if(res.ok){
      const data = await res.json();
      renderDocs(data);
    } else {
      renderDocs([]);
    }
  }catch(err){
    console.log('No backend', err);
    renderDocs([]);
  }
}

function renderDocs(items){
  const list = document.getElementById('docList');
  list.innerHTML = '';
  if(!items || items.length===0){
    list.innerHTML = '<p>Không có tài liệu (demo)</p>';
    return;
  }
  items.forEach(d => {
    const div = document.createElement('div');
    div.className = 'doc-item';
    div.innerHTML = `<h4>${d.title}</h4><p>${d.description || ''}</p><a href="${d.filePath||'#'}" target="_blank">Tải về</a>`;
    list.appendChild(div);
  });
}

function doSearch(){
  const q = document.getElementById('searchInput').value.trim();
  alert('Tìm kiếm (demo): ' + q);
}

async function sendChat(){
  const txt = document.getElementById('chatInput').value.trim();
  if(!txt) return;
  const win = document.getElementById('chatWindow');
  win.innerHTML += '<div><b>Bạn:</b> ' + escapeHtml(txt) + '</div>';
  // call AI endpoint
  try{
    const res = await fetch(API_BASE + '/ai/chat', {
      method: 'POST',
      headers: {'Content-Type':'application/json'},
      body: JSON.stringify({message: txt})
    });
    if(res.ok){
      const data = await res.json();
      win.innerHTML += '<div><b>AI:</b> ' + escapeHtml(data.reply || data.error || 'Không có phản hồi') + '</div>';
    } else {
      win.innerHTML += '<div><b>AI:</b> Lỗi gọi API</div>';
    }
  } catch(err){
    win.innerHTML += '<div><b>AI:</b> Không thể kết nối (demo)</div>';
    console.error(err);
  }
  document.getElementById('chatInput').value = '';
  win.scrollTop = win.scrollHeight;
}

function escapeHtml(s){ return s.replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;'); }
